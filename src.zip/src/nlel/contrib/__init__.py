# Admissions subset compatibility shims
